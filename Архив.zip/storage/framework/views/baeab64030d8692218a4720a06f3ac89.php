<?php $__env->startSection('title', 'Заказ # ' . $order->id); ?>

<?php $__env->startSection('content'); ?>

    <div class="page admin order">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <?php echo $__env->make('auth/layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-9">
                    <h1>Заказ #<?php echo e($order->id); ?></h1>
                    <p><b>Заказчик:</b> <?php echo e($order->name); ?></p>
                    <p><b>Телефон:</b> <a href="tel:<?php echo e($order->phone); ?>"><?php echo e($order->phone); ?></a></p>
                    <p><b>Способ доставки:</b> <?php echo e($order->type_address); ?></p>
                    <?php if($order->type_address == 'Заказать через курьера'): ?>
                        <p><b>Адрес:</b> <?php echo e($order->address); ?></p>
                        <p><b>Комментарий:</b> <?php echo e($order->comment); ?></p>
                    <?php endif; ?>
                    <p><b>Способ оплаты:</b> <?php echo e($order->type_payment); ?></p>
                    <p><b>Статус:</b> <?php echo e($order->label); ?></p>
                    <table class="table">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Название</th>
                            <th>Количество</th>
                            <th>Цена</th>
                            <th>Стоимость</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $skus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($sku->product->id); ?></td>
                                <td><a href="<?php echo e(route('sku', [$sku->product->category->code, $sku->product->code,
                                $sku->id])); ?>">
                                        <img src="<?php echo e(Storage::url($sku->product->image)); ?>" alt="">
                                        <div class="descr"><?php echo e($sku->product->title); ?></div>
                                    </a>
                                </td>
                                <td><?php echo e($sku->pivot->count); ?></td>
                                <td><?php echo e($sku->pivot->price); ?> <?php echo e($order->currency->symbol); ?></td>
                                <td><?php echo e($sku->pivot->price * $sku->pivot->count); ?> <?php echo e($order->currency->symbol); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td colspan="3">Общая стоимость:</td>
                            <td><?php echo e($order->sum); ?> <?php echo e($order->currency->symbol); ?></td>
                        </tr>
                        <?php if($order->hasCoupon()): ?>
                            <tr>
                                <td colspan="3">Был использован купон:</td>
                                <td><a href="<?php echo e(route('coupons.show', $order->coupon)); ?>"><?php echo e($order->coupon->code); ?></a></td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth/layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/phplaravel/resources/views/auth/orders/show.blade.php ENDPATH**/ ?>