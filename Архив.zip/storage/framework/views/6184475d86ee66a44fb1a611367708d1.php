<?php $__env->startSection('title', 'Каталог'); ?>

<?php $__env->startSection('content'); ?>

    <div class="pagetitle">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1><?php echo app('translator')->get('main.catalog'); ?></h1>
                    <h4><?php echo app('translator')->get('main.showed'); ?> <?php echo e($product->count()); ?></h4>
                    <div class="breadcrumbs">
                        <ul>
                            <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->get('main.home'); ?></a></li>
                            <li>/</li>
                            <li><?php echo app('translator')->get('main.catalog'); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="page products catalog category">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="filters">
                        <form action="<?php echo e(route('catalog')); ?>" method="get">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group form-label">
                                        <label for="">Выбрать категорию</label>
                                        <select name="category_id" id="">
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option
                                                        value="<?php echo e($category->id); ?>"
                                                        <?php if(@isset(request()->category_id)): ?>
                                                            <?php if(request()->category_id == $category->id): ?> selected <?php endif; ?>
                                                        <?php endif; ?>
                                                ><?php echo e($category->title); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group form-label">
                                        <label for="price_from">Цена от:</label>
                                        <input type="text" name="price_from" id="price_from"
                                               value="<?php echo e(request()->price_from); ?>">
                                    </div>
                                    <div class="form-group form-label">
                                        <label for="price_to">Цена до:</label>
                                        <input type="text" name="price_to" label="price_to" value="<?php echo e(request()
                                        ->price_to); ?>">
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="hit" name="hit" <?php if(request()->has('hit')): ?> checked
                                                <?php endif; ?>>
                                        <label for="hit"><?php echo app('translator')->get('main.properties.hit'); ?></label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="recommend" name="recommend" <?php if(request()->has
                                        ('recommend')): ?>
                                            checked <?php endif; ?>>
                                        <label for="recommend"><?php echo app('translator')->get('main.properties.recommend'); ?></label>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="new" name="new" <?php if(request()->has('new')): ?> checked
                                                <?php endif; ?>>
                                        <label for="new"><?php echo app('translator')->get('main.properties.new'); ?></label>
                                    </div>
                                    <div class="form-group btn-wrap">
                                        <button class="more"><?php echo app('translator')->get('main.filter'); ?></button>
                                        <a href="<?php echo e(route('catalog')); ?>" class="reset"><?php echo app('translator')->get('main.reset'); ?></a>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php if($skus->isNotEmpty()): ?>
                    <?php $__currentLoopData = $skus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 col-md-4 col-6">
                            <?php echo $__env->make('layouts.cart', compact('sku'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <h2>Продукции не найдены</h2>
                <?php endif; ?>
            </div>





        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/phplaravel/resources/views/catalog.blade.php ENDPATH**/ ?>