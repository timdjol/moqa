<?php if(isset($order)): ?>
    <?php $__env->startSection('title', 'Редактировать  ' . $order->name); ?>
<?php else: ?>
    <?php $__env->startSection('title', 'Создать заказ'); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <?php echo $__env->make('auth.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-9">
                    <?php if(isset($order)): ?>
                        <h1>Редактировать заказ <?php echo e($order->title); ?></h1>
                    <?php else: ?>
                        <h1>Создать заказ</h1>
                    <?php endif; ?>
                    <form method="post" enctype="multipart/form-data"
                          <?php if(isset($order)): ?>
                              action="<?php echo e(route('orders.update', $order)); ?>"
                          <?php else: ?>
                              action="<?php echo e(route('orders.store')); ?>"
                            <?php endif; ?>
                    >
                        <?php if(isset($order)): ?>
                            <?php echo method_field('PUT'); ?>
                        <?php endif; ?>
                        <?php echo $__env->make('auth.layouts.error', ['fieldname' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="form-group">
                            <label for="">ФИО</label>
                            <input type="text" name="name" value="<?php echo e(old('name', isset($order) ? $order->name :
                             null)); ?>">
                        </div>
                        <?php echo $__env->make('auth.layouts.error', ['fieldname' => 'phone'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="form-group">
                            <label for="">Номер телефона</label>
                            <input type="text" name="phone" value="<?php echo e(old('phone', isset($order) ? $order->phone :
                             null)); ?>">
                        </div>
                        <?php echo $__env->make('auth.layouts.error', ['fieldname' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="form-group">
                            <label for="">Email</label>
                            <input type="text" name="email" value="<?php echo e(old('email', isset($order) ?
                                $order->email : null)); ?>">
                        </div>
                        <?php echo $__env->make('auth.layouts.error', ['fieldname' => 'sum'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div class="form-group">
                                <label for="">Сумма</label>
                                <input type="text" name="sum" value="<?php echo e(old('sum', isset($order) ?
                                $order->sum : null)); ?>">
                            </div>
                            <?php echo $__env->make('auth.layouts.error', ['fieldname' => 'label'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div class="form-group">
                                <label for="">Статус</label>
                                <select name="label">
                                    <option value="<?php echo e($order->label); ?>"><?php echo e($order->label); ?></option>
                                    <option value="В процессе">В процессе</option>
                                    <option value="Выполнено">Выполнено</option>
                                    <option value="Отправлено">Отправлено</option>
                                    <option value="Возврат товара">Возврат товара</option>
                                    <option value="Отменено">Отменено</option>
                                </select>
                            </div>
                        <?php echo csrf_field(); ?>
                        <button class="more">Отправить</button>
                        <a href="<?php echo e(url()->previous()); ?>" class="btn delete cancel">Отмена</a>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/phplaravel/resources/views/auth/orders/form.blade.php ENDPATH**/ ?>