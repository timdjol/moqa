<?php $__env->startSection('title', 'Товарные предложения'); ?>

<?php $__env->startSection('content'); ?>

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <?php echo $__env->make('auth.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-9">
                    <div class="row">
                        <div class="col-md-7">
                            <h1>Товарные предложения</h1>
                            <h2><?php echo e($product->title); ?></h2>
                        </div>
                        <div class="col-md-5">
                            <a class="btn add" href="<?php echo e(route('skus.create', $product)); ?>">Добавить</a>
                        </div>
                    </div>
                    <table class="table">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>SKU</th>
                            <th>Цена</th>
                            <th>Действия</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $skus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($sku->id); ?></td>
                                <td><?php echo e($sku->propertyOptions->map->title->implode(', ')); ?></td>
                                <td><?php echo e($sku->price); ?></td>
                                <td><?php echo e($sku->count); ?></td>
                                <td>
                                    <form action="<?php echo e(route('skus.destroy', [$product, $sku])); ?>" method="post">
                                        <ul>
                                            <li><a class="btn view" href="<?php echo e(route('skus.show', [$product, $sku])); ?>">Открыть</a></li>
                                            <li><a class="btn edit" href="<?php echo e(route('skus.edit', [$product, $sku])); ?>">Редактировать</a></li>
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn delete">Удалить</button>
                                        </ul>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($skus->links()); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/phplaravel/resources/views/auth/skus/index.blade.php ENDPATH**/ ?>