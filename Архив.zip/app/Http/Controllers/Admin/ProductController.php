<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\ProductRequest;
use App\Models\Category;
use App\Models\Image;
use App\Models\Product;
use App\Models\Property;
use App\Models\Sku;
use Illuminate\Support\Facades\Storage;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $products = Product::paginate(10);
        return view('auth.products.index', compact('products'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $categories = Category::get();;
        $properties = Property::get();
        return view('auth.products.form', compact('categories', 'properties'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(ProductRequest $request, Product $product, Image $image)
    {
        $params = $request->all();

        $params['product_id'] = 1;
        //dd($params['product_id']);

        //unset($params['image']);
        //$paths = [];

        $images = [];
        if ($request->file('image')){
            foreach($request->file('image') as $key => $image)
            {
                $image_name = $image->store('products');
                $images[]['image'] = $image_name;
                $imageModel = new Image;
                $imageModel->image = $image_name;
                $image->product_id = 1;
            }
        }

        //$image->create($images[]);





//        if($request->has('image')){
////            $path = $request->file('image')->store('products');
////            $params['image'] = $path;
//
//
//            foreach($request->file('image') as $image){
//                $paths[]['image'] = $image->store('images');
//                //$params['image'] = $path;
//
//                //dd($params);
//
//                //$product = Product::class;
//
//                $last_id = Product::get()->last()->id;
//
////                $request->product->getImages()->create([
////                    'product_id' => $request->product->id,
////                    'image' => $path
////                ]);
//
//            }
//
//            dd($paths);
//
//        }


        $product->create($params);
        session()->flash('success', 'Продукция ' . $request->title . ' добавлена');
        return redirect()->route('products.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(Product $product, Sku $sku)
    {
        return view('auth.products.show', compact('product', 'sku'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Product $product)
    {
        $categories = Category::get();
        $properties = Property::get();
        session()->flash('success', 'Продукция ' . $product->title . ' добавлена');
        return view('auth.products.form', compact('product', 'categories', 'properties'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(ProductRequest $request, Product $product)
    {
        $params = $request->all();
        unset($params['image']);
        if($request->has('image')){
            Storage::delete($product->image);
            $path = $request->file('image')->store('products');
            $params['image'] = $path;
        }
        foreach (['new', 'hit', 'recommend'] as $fieldName){
            if(!isset($params[$fieldName])){
                $params[$fieldName] = 0;
            }
        }

        $product->properties()->sync($request->property_id);
        $product->update($params);
        session()->flash('success', 'Продукция ' . $product->title . ' обновлена');
        return redirect()->route('products.index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Product $product)
    {
        $product->delete();
        session()->flash('success', 'Продукция ' . $product->title . ' удалена');
        return redirect()->route('products.index');
    }

}
