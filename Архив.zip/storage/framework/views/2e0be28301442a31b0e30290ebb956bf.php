<?php $__env->startSection('title', 'Контакты'); ?>

<?php $__env->startSection('content'); ?>

    <div class="pagetitle">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1><?php echo e($page->title); ?></h1>
                    <div class="breadcrumbs">
                        <ul>
                            <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->get('main.home'); ?></a></li>
                            <li>/</li>
                            <li><?php echo e($page->title); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="page contacts pt0">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-12">
                    <div class="phone"><a href="tel:996500566366"><?php echo e($contacts->first()->phone); ?></a></div>
                    <div class="soc">
                        <ul>
                            <li><a href="<?php echo e($contacts->first()->whatsapp); ?>" target="_blank"><img src="<?php echo e(url('/')); ?>/img/whatsapp.svg"
                                                                                                  alt=""></a></li>
                            <li><a href="<?php echo e($contacts->first()->instagram); ?>" target="_blank"><img src="<?php echo e(url('/')); ?>/img/instagram.svg" alt=""></a>
                            </li>
                            <li><a href="<?php echo e($contacts->first()->telegram); ?>" target="_blank"><img src="<?php echo e(url('/')); ?>/img/telegram.svg" alt=""></a></li>
                        </ul>
                    </div>
                    <?php echo $page->description; ?>

                    <form action="">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <input type="text" placeholder="<?php echo app('translator')->get('basket.your_name'); ?>">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <input type="text" placeholder="Email" required>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <input type="text" placeholder="<?php echo app('translator')->get('basket.phone'); ?>" required>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <textarea name="" rows="4" placeholder="<?php echo app('translator')->get('main.message'); ?>"></textarea>
                                <button class="more" id="send"><?php echo app('translator')->get('main.send'); ?></button>
                            </div>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/phplaravel/resources/views/pages/contacts.blade.php ENDPATH**/ ?>