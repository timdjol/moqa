<?php $__env->startSection('content'); ?>

    <div class="pagetitle">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1><?php echo e($category->__('title')); ?></h1>

                    <div class="breadcrumbs">
                        <ul>
                            <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->get('main.home'); ?></a></li>
                            <li>/</li>
                            <li><a href="<?php echo e(route('catalog')); ?>"><?php echo app('translator')->get('main.catalog'); ?></a></li>
                            <li>/</li>
                            <li><?php echo e($category->__('title')); ?></li>
                        </ul>
                    </div>
                    <h4><?php echo app('translator')->get('main.showed'); ?> <?php echo e($category->products->count()); ?></h4>
                </div>
            </div>
        </div>
    </div>

    <div class="products category">
        <div class="container">
            <div class="row">
                <?php if($category->products->map->skus->flatten()->isNotEmpty()): ?>
                    <?php $__currentLoopData = $category->products->map->skus->flatten()->unique('product_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 col-md-4 col-6">
                            <?php echo $__env->make('layouts.cart', compact('sku'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <h2>Продукции не найдены</h2>
                <?php endif; ?>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="pagination">

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/phplaravel/resources/views/category.blade.php ENDPATH**/ ?>