<?php $__env->startSection('title', 'Продукция'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo e(dump($skus)); ?>


    <div class="pagetitle">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1><?php echo app('translator')->get('main.catalog'); ?></h1>

                    <div class="breadcrumbs">
                        <ul>
                            <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->get('main.home'); ?></a></li>
                            <li>/</li>
                            <li><a href="<?php echo e(route('catalog')); ?>"><?php echo app('translator')->get('main.catalog'); ?></a></li>
                            <li>/</li>
                            <li><?php echo e($skus->product->__('title')); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="single">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="row gallery">
                        <div class="col-md-6 col-6">
                            <a href="<?php echo e(Storage::url($skus->product->image)); ?>">
                                <div class="img" style="background-image: url(<?php echo e(Storage::url($skus->product->image)); ?>)
                                "></div>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <h1><?php echo e($skus->product->__('title')); ?></h1>
                    <h5><?php echo e($skus->product->category->__('title')); ?></h5>
                    <div class="price"><?php echo e($skus->price); ?> <?php echo e($currencySymbol); ?></div>
                    <?php if(isset($skus->product->properties)): ?>
                        <?php $__currentLoopData = $skus->propertyOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $propertyOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p><?php echo e($propertyOption->property->__('title')); ?>: <?php echo e($propertyOption->__
                ('title')); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <div class="colors">
                        <ul>
                            <li class="gold current"></li>
                            <li class="black"></li>
                        </ul>
                    </div>
                    <div class="size">
                        <form action="">
                            <select name="" id="">
                                <option>Выбрать</option>
                                <option value="">XXS</option>
                                <option value="">XS</option>
                                <option value="">S</option>
                                <option value="">M</option>
                                <option value="">L</option>
                                <option value="">XL</option>
                            </select>
                        </form>
                    </div>
                    <div class="btn-wrap">
                        <div class="buy">
                            <?php if($skus->isAvailable()): ?>
                                <form action="<?php echo e(route('basket-add', $skus->product)); ?>" method="post">
                                    <button class="more" type="submit"><?php echo app('translator')->get('main.addtocart'); ?></button>
                                    <?php echo csrf_field(); ?>
                                </form>
                            <?php else: ?>
                                <span><?php echo app('translator')->get('main.no_available'); ?></span><br>
                                <span><?php echo app('translator')->get('main.subscription'); ?></span>
                                <?php if($errors->get('email')): ?>
                                    <div class="alert alert-warning">
                                        <?php echo $errors->get('email')[0]; ?>

                                    </div>
                                <?php endif; ?>
                                <form action="<?php echo e(route('subscription', $skus)); ?>" method="post">
                                    <div class="form-group">
                                        <input type="text" name="email" placeholder="<?php echo app('translator')->get('main.your_email'); ?>">
                                    </div>
                                    <?php echo csrf_field(); ?>
                                    <button class="more"><?php echo app('translator')->get('send'); ?></button>
                                </form>
                            <?php endif; ?>
                        </div>
                        <div class="click">
                            <a href="#click" class="more">Купить в один клик</a>
                            <div class="hidden">
                                <form action="" class="form-callback" id="click">
                                    <h3>Купить в один клик</h3>

                                    <input type="hidden" name="product" value="<?php echo e($skus->product->__('title')); ?>">
                                    <input type="hidden" name="price" value="<?php echo e($skus->price); ?> <?php echo e($currencySymbol); ?>">
                                    <div class="form-group">
                                        <label for="">Ваше имя</label>
                                        <input type="text" name="name">
                                    </div>
                                    <div class="form-group">
                                        <label for="">Номер телефона</label>
                                        <input type="text" name="phone">
                                    </div>
                                    <button class="more">Отправить</button>
                                </form>
                            </div>
                        </div>
                        <div class="wish">
                            <form action="<?php echo e(route('wishlist-add', $skus)); ?>" method="POST">
                                <button>
                                    <svg width="800px" height="800px" viewBox="0 0 64 64"
                                         xmlns="http://www.w3.org/2000/svg"
                                         stroke-width="1.5"
                                         stroke="#fff" fill="none">
                                        <path d="M9.06,25C7.68,17.3,12.78,10.63,20.73,10c7-.55,10.47,7.93,11.17,9.55a.13.13,0,0,0,.25,0c3.25-8.91,9.17-9.29,11.25-9.5C49,9.45,56.51,13.78,55,23.87c-2.16,14-23.12,29.81-23.12,29.81S11.79,40.05,9.06,25Z"/>
                                    </svg>
                                </button>
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </div>
                    <div class="choose">
                        <a href="#choose_size"><?php echo app('translator')->get('main.choose_size'); ?></a>
                        <div class="hidden">
                            <div id="choose_size" class="form-callback size-wrap">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="img" style="background-image: url('<?php echo e(route('index')); ?>/img/prod1.jpeg')
                                        "></div>
                                    </div>
                                    <div class="col-md-9">
                                        <h3>Найдите в таблице параметры, близкие к вашим, чтобы определить свой
                                            размер</h3>
                                        <table class="table">
                                            <thead>
                                            <tr>
                                                <th>INT</th>
                                                <th>RU</th>
                                                <th>Обхват груди</th>
                                                <th>Обхват талии</th>
                                                <th>Обхват бедер</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <tr>
                                                <td>XXS</td>
                                                <td>40</td>
                                                <td>80</td>
                                                <td>60</td>
                                                <td>88</td>
                                            </tr>
                                            <tr>
                                                <td>XS</td>
                                                <td>42</td>
                                                <td>84</td>
                                                <td>64</td>
                                                <td>92</td>
                                            </tr>
                                            <tr>
                                                <td>S</td>
                                                <td>44</td>
                                                <td>88</td>
                                                <td>68</td>
                                                <td>96</td>
                                            </tr>
                                            <tr>
                                                <td>M</td>
                                                <td>46</td>
                                                <td>92</td>
                                                <td>72</td>
                                                <td>100</td>
                                            </tr>
                                            <tr>
                                                <td>L</td>
                                                <td>48</td>
                                                <td>96</td>
                                                <td>76</td>
                                                <td>104</td>
                                            </tr>
                                            <tr>
                                                <td>XL</td>
                                                <td>50</td>
                                                <td>100</td>
                                                <td>80</td>
                                                <td>108</td>
                                            </tr>
                                            </tbody>
                                        </table>
                                        <p>*Все размеры указаны в см</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tech">
                        <ul>
                            <li><?php echo app('translator')->get('main.sku'); ?>: 120632</li>
                            <li><?php echo app('translator')->get('main.parameters'); ?>: 178/84/60/89</li>
                            <li><?php echo app('translator')->get('main.model_size'); ?>: S</li>
                        </ul>
                    </div>
                    <div class="descr">
                        <?php echo e($skus->product->__('description')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="products related">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2><?php echo app('translator')->get('main.related'); ?></h2>
                    <div class="owl-carousel owl-products">
                        <?php $__currentLoopData = $related->map->skus->flatten(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('layouts.cart', compact('sku'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="products view">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2><?php echo app('translator')->get('main.recently'); ?></h2>
                    <div class="owl-carousel owl-products">
                        <?php $__currentLoopData = $recently->map->skus->flatten(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('layouts.cart', compact('sku'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/phplaravel/resources/views/product.blade.php ENDPATH**/ ?>