<p><?php echo app('translator')->get('mail.dear'); ?> <?php echo e($name); ?></p>

<p><?php echo app('translator')->get('mail.order_sum'); ?> <?php echo e($fullSum); ?> <?php echo e($order->currency->symbol); ?> <?php echo app('translator')->get('mail.order_create'); ?></p>

<table>
    <tbody>
    <?php $__currentLoopData = $order->skus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <a href="<?php echo e(route('sku', [$sku->product->category->code, $sku->product->code, $sku->id])); ?>">
                    <img src="<?php echo e(Storage::url($sku->product->image)); ?>" alt="<?php echo e($sku->product->__('title')); ?>">
                    <?php echo e($sku->product->__('title')); ?>

                </a>
            </td>
            <td>
                <span class="badge"><?php echo e($sku->countInOrder); ?></span>
            </td>
            <td><?php echo e($sku->price); ?> <?php echo e($order->currency->symbol); ?></td>
            <td><?php echo e($sku->getPriceForCount()); ?> <?php echo e($order->currency->symbol); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH /Users/timdjol/Sites/localhost/phplaravel/resources/views/mail/order_created.blade.php ENDPATH**/ ?>