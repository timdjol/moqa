<?php $__env->startSection('title', 'Доставка'); ?>

<?php $__env->startSection('content'); ?>

    <div class="pagetitle">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1><?php echo e($page->title); ?></h1>
                    <div class="breadcrumbs">
                        <ul>
                            <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->get('main.home'); ?></a></li>
                            <li>/</li>
                            <li><?php echo e($page->title); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="page delivery pt0">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-12">
                    <?php echo $page->description; ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/phplaravel/resources/views/pages/delivery.blade.php ENDPATH**/ ?>