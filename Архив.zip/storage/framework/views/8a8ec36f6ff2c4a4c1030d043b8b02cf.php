<h2>Профиль</h2>





<form method="post" action="<?php echo e(route('profile.update')); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('patch'); ?>
    <div class="form-group">
        <label for="">Ваше имя</label>
        <input type="text" name="name" value="<?php echo e(old('name', $user->name)); ?>">
    </div>

    <div class="form-group">
        <label for="">Email</label>
        <input type="email" name="email" value="<?php echo e(old('name', $user->email)); ?>">
        <?php if($user instanceof \Illuminate\Contracts\Auth\MustVerifyEmail && ! $user->hasVerifiedEmail()): ?>
            <div>
                <p class="text-sm mt-2 text-gray-800 dark:text-gray-200">
                    <?php echo e(__('Your email address is unverified.')); ?>


                    <button form="send-verification"
                            class="underline text-sm text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800">
                        <?php echo e(__('Click here to re-send the verification email.')); ?>

                    </button>
                </p>

                <?php if(session('status') === 'verification-link-sent'): ?>
                    <p class="mt-2 font-medium text-sm text-green-600 dark:text-green-400">
                        <?php echo e(__('A new verification link has been sent to your email address.')); ?>

                    </p>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
    <button class="more">Сохранить</button>
    <?php if(session('status') === 'profile-updated'): ?>
        <p>Сохранено</p>
    <?php endif; ?>
</form>
<?php /**PATH /Users/timdjol/Sites/localhost/phplaravel/resources/views/profile/partials/update-profile-information-form.blade.php ENDPATH**/ ?>