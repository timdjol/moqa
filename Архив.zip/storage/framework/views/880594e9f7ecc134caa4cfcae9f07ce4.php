<?php $__env->startSection('title', 'Отзывы'); ?>

<?php $__env->startSection('content'); ?>

    <div class="pagetitle">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1><?php echo e($page->title); ?></h1>
                    <div class="breadcrumbs">
                        <ul>
                            <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->get('main.home'); ?></a></li>
                            <li>/</li>
                            <li><?php echo e($page->title); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="page reviews pt0">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2 col-md-12">
                    <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="reviews-item">
                            <div class="img" style="background-image: url(<?php echo e(Storage::url($review->image)); ?>)"></div>
                            <h4><?php echo e($review->__('title')); ?></h4>
                            <div class="text-wrap">
                                <p><?php echo $review->__('description'); ?></p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/phplaravel/resources/views/pages/reviews.blade.php ENDPATH**/ ?>