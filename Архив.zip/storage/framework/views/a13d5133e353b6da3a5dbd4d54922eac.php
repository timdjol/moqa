<?php $__env->startSection('title', 'Консоль'); ?>

<?php $__env->startSection('content'); ?>

<div class="page admin dashboard">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <?php echo $__env->make('auth/layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col-md-9">
                <?php if(session()->has('success')): ?>
                    <p class="alert alert-success"><?php echo e(session()->get('success')); ?></p>
                <?php endif; ?>
                <?php if(session()->has('warning')): ?>
                    <p class="alert alert-warning"><?php echo e(session()->get('warning')); ?></p>
                <?php endif; ?>
                <h1>Добро пожаловать <?php echo e($user->name); ?></h1>
                <div class="row justify-content-center">
                    <div class="col-md-4">
                        <div class="dashboard-item">
                            <div class="num"><?php echo e($order->count()); ?></div>
                            <h5>Количество <br> заказов</h5>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="dashboard-item">
                            <div class="num"><?php echo e($user->count()); ?></div>
                            <h5>Количество <br> пользователей</h5>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="dashboard-item">
                            <div class="num"><?php echo e($product->count()); ?></div>
                            <h5>Количество <br> продукций</h5>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="dashboard-item">
                            <div class="num"><?php echo e($categories->count()); ?></div>
                            <h5>Количество <br> категорий</h5>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="dashboard-item">
                            <div class="num"><?php echo e($page->count()); ?></div>
                            <h5>Количество <br> страниц</h5>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="dashboard-item">
                            <div class="num"><?php echo e($coupon->count()); ?></div>
                            <h5>Количество <br> купонов</h5>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="sliders">
                            <h3>Слайды</h3>
                            <p>Количество слайдов: <?php echo e($sliders->count()); ?></p>
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>Изображение</th>
                                    <th>Название</th>
                                    <th>Действия</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><img src="<?php echo e(Storage::url($slider->image)); ?>" alt=""></td>
                                        <td><?php echo e($slider->title); ?></td>
                                        <td>
                                            <form action="<?php echo e(route('sliders.destroy', $slider)); ?>" method="post">
                                                <ul>
                                                    <li><a class="btn edit" href="<?php echo e(route('sliders.edit', $slider)); ?>">Редактировать</a></li>
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button class="btn delete">Удалить</button>
                                                </ul>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <a class="btn add" href="<?php echo e(route('sliders.create')); ?>">Добавить слайд</a>
                            <?php echo e($sliders->links('pagination::bootstrap-4')); ?>

                        </div>

                        <div class="reviews">
                            <h3>Отзывы</h3>
                            <p>Количество отзывов: <?php echo e($reviews->count()); ?></p>
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>Изображение</th>
                                    <th>Название</th>
                                    <th>Действия</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><img src="<?php echo e(Storage::url($review->image)); ?>" alt=""></td>
                                        <td><?php echo e($review->title); ?></td>
                                        <td>
                                            <form action="<?php echo e(route('sliders.destroy', $review)); ?>" method="post">
                                                <ul>
                                                    <li><a class="btn edit" href="<?php echo e(route('reviews.edit', $review)); ?>">Редактировать</a></li>
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button class="btn delete">Удалить</button>
                                                </ul>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <a class="btn add" href="<?php echo e(route('reviews.create')); ?>">Добавить отзыв</a>
                            <?php echo e($reviews->links('pagination::bootstrap-4')); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth/layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/phplaravel/resources/views/auth/dashboard.blade.php ENDPATH**/ ?>