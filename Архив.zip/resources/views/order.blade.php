@extends('layouts.master')

@section('title', 'Оформление заказа')

@section('content')
    <div class="page order">
        <div class="container">
            <div class="col-lg-6 col-md-12 offset-lg-3">
                <h1>@lang('basket.checkout')</h1>
                <h5>@lang('basket.total_order'): {{ $order->getFullSum() }} {{
                $currencySymbol }}</h5>
                <form action="{{ route('order-confirm') }}" method="post">
                    @error ('name')
                    <div class="alert alert-danger">{{ $message }}</div>
                    @enderror
                    <div class="form-group">
                        <label for="">@lang('basket.your_name')</label>
                        <input type="text" name="name" value="{{ old('name', isset($order) ? $order->name :
                             null) }}">
                    </div>
                    @error ('phone')
                    <div class="alert alert-danger">{{ $message }}</div>
                    @enderror
                    <div class="form-group">
                        <label for="">@lang('basket.phone')</label>
                        <input type="text" name="phone" value="{{ old('phone', isset($order) ? $order->phone :
                             null) }}">
                    </div>
                    @guest
                        @error ('email')
                        <div class="alert alert-danger">{{ $message }}</div>
                        @enderror
                        <div class="form-group">
                            <label for="">Email</label>
                            <input type="email" name="email">
                        </div>
                    @endguest
                    <br>
                    <div class="delivery">
                        <div class="form-group">
                            <h5>Способы доставки</h5>
                            <input type="radio" id="del_1" name="type_address" value="Заказать через курьера" checked>
                            <label for="del_1">Заказать через курьера</label>
                        </div>
                        <div id="form1">
                            <div class="form-group">
                                <label for="">Адрес доставки</label>
                                <input type="text" name="address" value="{{ old('address', isset($order) ? $order->address :
                             null) }}">
                            </div>
                            <div class="form-group">
                                <label for="comment">Комментарий для курьера</label>
                                <textarea name="comment" id="comment" rows="3">{{ old('comment', isset($order) ?
                        $order->comment :
                             null) }}</textarea>
                            </div>
                        </div>

                        <div class="form-group">
                            <input type="radio" id="del_2" name="type_address" value="Самовывоз">
                            <label for="del_2">Самовывоз</label>
                        </div>
                        <div id="form2">
                            <div class="form-group">
                                <p>г. Бишкек ул. Советская 3/4</p>
                            </div>
                        </div>
                    </div>

                    <br>
                    <div class="paymentblock">
                        <div class="form-group">
                            <h5>Способы оплаты</h5>
                            <input type="radio" id="nal" name="type_payment" value="Наличными" checked>
                            <label for="nal">Наличными</label>
                        </div>
                        <div class="form-group">
                            <input type="radio" id="bank" value="Банковской картой" name="type_payment">
                            <label for="bank">Банковской картой</label>
                        </div>
                        <div id="form3">
                            <h4>VISA</h4>
                        </div>
                    </div>

                    @csrf
                    <button class="more">@lang('basket.confirm')</button>
                </form>
            </div>
        </div>
    </div>
@endsection

<style>
    .form-group input[type="radio"]{
        width: auto;
        height: auto;
    }
    #form2, #form3{
        display: none;
    }
</style>