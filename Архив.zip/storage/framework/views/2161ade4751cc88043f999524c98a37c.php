<?php $__env->startSection('title', 'Варианты свойства'); ?>

<?php $__env->startSection('content'); ?>

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <?php echo $__env->make('auth.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-9">
                    <div class="row">
                        <div class="col-md-7">
                            <h1>Варианты свойства</h1>
                        </div>
                        <div class="col-md-5">
                            <a class="btn add" href="<?php echo e(route('property-options.create', $property)); ?>">Добавить</a>
                        </div>
                    </div>
                    <table class="table">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Свойство</th>
                            <th>Название</th>
                            <th>Действия</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $propertyOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $propertyOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($propertyOption->id); ?></td>
                                <td><?php echo e($propertyOption->property->title); ?></td>
                                <td><?php echo e($propertyOption->title); ?></td>
                                <td>
                                    <form action="<?php echo e(route('property-options.destroy', [$property, $propertyOption])); ?>"
                                          method="post">
                                        <ul>
                                            <li><a class="btn view" href="<?php echo e(route('property-options.show',
                                            [$property, $propertyOption])); ?>">Открыть</a></li>
                                            <li><a class="btn edit" href="<?php echo e(route('property-options.edit',
                                            [$property, $propertyOption])); ?>">Редактировать</a></li>
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn delete">Удалить</button>
                                        </ul>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($propertyOptions->links('pagination::bootstrap-4')); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/phplaravel/resources/views/auth/property_options/index.blade.php ENDPATH**/ ?>