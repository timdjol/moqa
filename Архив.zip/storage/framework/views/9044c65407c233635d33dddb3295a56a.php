<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo app('translator')->get('main.online_shop'); ?> - <?php echo $__env->yieldContent('title'); ?> - Moqa</title>
    <link rel="stylesheet" href="<?php echo e(route('index')); ?>/css/main.min.css">
    <link rel="stylesheet" href="<?php echo e(route('index')); ?>/css/admin.css">
    <link rel="stylesheet" href="<?php echo e(route('index')); ?>/css/style.css">
</head>
<body>

<header>
    <div class="top-head">
        <div class="container">
            <div class="row">
                <div class="col-md-2">
                    <div class="logo">
                        <a href="<?php echo e(route('index')); ?>"><img src="<?php echo e(url('/')); ?>/img/logo.png" alt=""></a>
                    </div>
                </div>
                <div class="col-md-10">
                    <div class="search d-xl-inline-block d-lg-inline-block d-md-inline-block d-none">
                        <form action="<?php echo e(route('search')); ?>" method="GET">
                            <input type="text" placeholder="<?php echo app('translator')->get('main.search'); ?>..." name="search">
                            <button><img src="<?php echo e(url('/')); ?>/img/search.svg" alt=""></button>
                        </form>
                    </div>
                    <div class="search d-xl-none d-lg-none d-lg-none d-inline-block">
                        <a href="#search"><img src="<?php echo e(url('/')); ?>/img/search.svg" alt=""></a>
                    </div>
                    <div class="lk">
                        <?php if(auth()->guard()->guest()): ?>
                            <li><a href="<?php echo e(route('login')); ?>"><img src="<?php echo e(url('/')); ?>/img/user.svg" alt=""></a></li>
                        <?php endif; ?>
                        <?php if(auth()->guard()->check()): ?>
                            <?php if (\Illuminate\Support\Facades\Blade::check('admin')): ?>
                            <li><a href="<?php echo e(route('dashboard')); ?>"><img src="<?php echo e(url('/')); ?>/img/user.svg" alt=""></a></li>
                        <?php else: ?>
                            <li><a href="<?php echo e(route('person.orders.index')); ?>"><img src="<?php echo e(url('/')); ?>/img/user.svg" alt=""></a></li>
                            <?php endif; ?>
                            <li><a href="<?php echo e(route('get-logout')); ?>"><?php echo app('translator')->get('main.exit'); ?></a></li>
                        <?php endif; ?>
                    </div>
                    <div class="cart">
                        <a href="<?php echo e(route('basket')); ?>"><img src="<?php echo e(url('/')); ?>/img/cart.svg" alt=""></a>
                    </div>
                    <div class="wish">
                        <a href="<?php echo e(route('wishlist')); ?>"><img src="<?php echo e(url('/')); ?>/img/wish.svg" alt=""></a>
                    </div>
                    <div class="lang">
                        <ul>
                            <li class="
                            <?php if(session('locale')=='ru'): ?>
                                current
                            <?php endif; ?>
                            "><a href="<?php echo e(route('locale', 'ru')); ?>">RU</a></li>
                            <li class="
                            <?php if(session('locale')=='en'): ?>
                                current
                            <?php endif; ?>
                            "><a href="<?php echo e(route('locale', 'en')); ?>">EN</a></li>
                        </ul>
                    </div>
                    <div class="currency">
                        <ul>
                            <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li
                                  <?php if($currencySymbol == $currency->symbol): ?> class="current"
                                        <?php endif; ?>
                                ><a href="<?php echo e(route('currency', $currency->code)); ?>"><?php echo e($currency->symbol); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="head">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <nav>
                        <a href="#" class="toggle-mnu d-xl-none d-lg-none"><span></span></a>
                        <ul>
                            <li <?php echo Route::currentRouteNamed('index') ? 'class="active"' : ''  ?>><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->get('main.home'); ?></a></li>
                            <li <?php echo Route::currentRouteNamed('cat*') ? 'class="active"' : ''  ?>><a href="<?php echo e(route('catalog')); ?>"><?php echo app('translator')->get('main.catalog'); ?></a></li>
                            <li <?php echo Route::currentRouteNamed('payment') ? 'class="active"' : ''  ?>><a href="<?php echo e(route('payment')); ?>"><?php echo app('translator')->get('main.payment'); ?></a></li>
                            <li <?php echo Route::currentRouteNamed('delivery') ? 'class="active"' : ''  ?>><a href="<?php echo e(route('delivery')); ?>"><?php echo app('translator')->get('main.delivery'); ?></a></li>
                            <li <?php echo Route::currentRouteNamed('refund') ? 'class="active"' : ''  ?>><a href="<?php echo e(route('refund')); ?>"><?php echo app('translator')->get('main.refund'); ?></a></li>
                            <li <?php echo Route::currentRouteNamed('about') ? 'class="active"' : ''  ?>><a href="<?php echo e(route('about')); ?>"><?php echo app('translator')->get('main.about'); ?></a></li>
                            <li <?php echo Route::currentRouteNamed('contactspage') ? 'class="active"' : ''  ?>><a href="<?php echo e(route('contactspage')); ?>"><?php echo app('translator')->get('main.contacts'); ?>
                            </a></li>
                            <li <?php echo Route::currentRouteNamed('cooperation') ? 'class="active"' : ''  ?>><a href="<?php echo e(route('cooperation')); ?>"><?php echo app('translator')->get('main.cooperation'); ?>
                            </a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</header>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <?php if(session()->has('success')): ?>
                <p class="alert alert-success"><?php echo e(session()->get('success')); ?></p>
            <?php endif; ?>
            <?php if(session()->has('warning')): ?>
                <p class="alert alert-warning"><?php echo e(session()->get('warning')); ?></p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php echo $__env->yieldContent('content'); ?>

<footer>
    <div class="footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="footer-item">
                        <div class="logo">
                            <img src="<?php echo e(url('/')); ?>/img/logo.png" alt="">
                            <div class="best">
                                <ul>
                                    <?php $__currentLoopData = $bestSkus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bestSku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(route('sku', [$bestSku->product->category->code,
                                        $bestSku->product->code, $bestSku])); ?>"><?php echo e($bestSku->product->__('title')); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="footer-item">
                        <h4><?php echo app('translator')->get('main.catalog'); ?></h4>
                        <ul>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('category', $category->code)); ?>"><?php echo e($category->__('title')); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="footer-item">
                        <h4><?php echo app('translator')->get('main.buyers'); ?></h4>
                        <ul>
                            <li><a href="<?php echo e(route('categories')); ?>">Все категории</a></li>
                            <li><a href="<?php echo e(route('delivery')); ?>">Доставка</a></li>
                            <li><a href="<?php echo e(route('refund')); ?>">Возврат</a></li>
                            <li><a href="<?php echo e(route('where')); ?>">Где купить?</a></li>
                            <li><a href="<?php echo e(route('policy')); ?>">Политика конфиденциальности</a></li>
                            <li><a href="<?php echo e(route('reviews')); ?>">Отзывы</a></li>
                            <li><a href="<?php echo e(route('about')); ?>">О нас</a></li>
                            <li><a href="<?php echo e(route('cooperation')); ?>">Сотрудничество</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="footer-item">
                        <h4><?php echo app('translator')->get('main.contacts'); ?></h4>
                        <div class="phone"><a href="tel:<?php echo e($contacts->first()->phone); ?>"><?php echo e($contacts->first()->phone); ?></a></div>
                        <div class="soc">
                            <ul>
                                <li><a href="<?php echo e($contacts->first()->whatsapp); ?>" target="_blank"><img src="<?php echo e(url('/')); ?>/img/whatsapp.svg"
                                                                                              alt=""></a></li>
                                <li><a href="<?php echo e($contacts->first()->instagram); ?>" target="_blank"><img src="<?php echo e(url('/')); ?>/img/instagram.svg" alt=""></a>
                                </li>
                                <li><a href="<?php echo e($contacts->first()->telegram); ?>" target="_blank"><img src="<?php echo e(url('/')); ?>/img/telegram.svg" alt=""></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="copy">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <p>MOQA <?php echo e(date('Y')); ?></p>
                </div>
            </div>
        </div>
    </div>
</footer>

<script src="<?php echo e(route('index')); ?>/js/scripts.min.js"></script>

<script>
    $(document).ready(function() {
        $('.delivery input[type="radio"]').click(function() {
            if($(this).attr('id') == 'del_1') {
                $('#form1').show();
                $('#form2').hide();
            }
            else {
                $('#form1').hide();
                $('#form2').show();
            }
        });

        $('.paymentblock input[type="radio"]').click(function() {
            if($(this).attr('id') == 'bank') {
                $('#form3').show();
            }
            else {
                $('#form3').hide();
            }
        });

    });
</script>
</body>
</html>
<?php /**PATH /Users/timdjol/Sites/localhost/phplaravel/resources/views/layouts/master.blade.php ENDPATH**/ ?>