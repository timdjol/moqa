<?php

return [
    'dear' => 'Dear ',
    'order_sum' => '>Your order for the amount ',
    'order_create' => ' has been created',
];