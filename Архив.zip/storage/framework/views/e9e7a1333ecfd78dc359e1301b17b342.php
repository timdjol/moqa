<?php $__env->startSection('title', 'Оформление заказа'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page order">
        <div class="container">
            <div class="col-lg-6 col-md-12 offset-lg-3">
                <h1><?php echo app('translator')->get('basket.checkout'); ?></h1>
                <h5><?php echo app('translator')->get('basket.total_order'); ?>: <?php echo e($order->getFullSum()); ?> <?php echo e($currencySymbol); ?></h5>
                <form action="<?php echo e(route('order-confirm')); ?>" method="post">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="form-group">
                        <label for=""><?php echo app('translator')->get('basket.your_name'); ?></label>
                        <input type="text" name="name" value="<?php echo e(old('name', isset($order) ? $order->name :
                             null)); ?>">
                    </div>
                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="form-group">
                        <label for=""><?php echo app('translator')->get('basket.phone'); ?></label>
                        <input type="text" name="phone" value="<?php echo e(old('phone', isset($order) ? $order->phone :
                             null)); ?>">
                    </div>
                    <?php if(auth()->guard()->guest()): ?>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="form-group">
                            <label for="">Email</label>
                            <input type="email" name="email">
                        </div>
                    <?php endif; ?>
                    <br>
                    <div class="delivery">
                        <div class="form-group">
                            <h5>Способы доставки</h5>
                            <input type="radio" id="del_1" name="type_address" value="Заказать через курьера" checked>
                            <label for="del_1">Заказать через курьера</label>
                        </div>
                        <div id="form1">
                            <div class="form-group">
                                <label for="">Адрес доставки</label>
                                <input type="text" name="address" value="<?php echo e(old('address', isset($order) ? $order->address :
                             null)); ?>">
                            </div>
                            <div class="form-group">
                                <label for="comment">Комментарий для курьера</label>
                                <textarea name="comment" id="comment" rows="3"><?php echo e(old('comment', isset($order) ?
                        $order->comment :
                             null)); ?></textarea>
                            </div>
                        </div>

                        <div class="form-group">
                            <input type="radio" id="del_2" name="type_address" value="Самовывоз">
                            <label for="del_2">Самовывоз</label>
                        </div>
                        <div id="form2">
                            <div class="form-group">
                                <p>г. Бишкек ул. Советская 3/4</p>
                            </div>
                        </div>
                    </div>

                    <br>
                    <div class="paymentblock">
                        <div class="form-group">
                            <h5>Способы оплаты</h5>
                            <input type="radio" id="nal" name="type_payment" value="Наличными" checked>
                            <label for="nal">Наличными</label>
                        </div>
                        <div class="form-group">
                            <input type="radio" id="bank" value="Банковской картой" name="type_payment">
                            <label for="bank">Банковской картой</label>
                        </div>
                        <div id="form3">
                            <h4>VISA</h4>
                        </div>
                    </div>

                    <?php echo csrf_field(); ?>
                    <button class="more"><?php echo app('translator')->get('basket.confirm'); ?></button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<style>
    .form-group input[type="radio"]{
        width: auto;
        height: auto;
    }
    #form2, #form3{
        display: none;
    }
</style>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/phplaravel/resources/views/order.blade.php ENDPATH**/ ?>