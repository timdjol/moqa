<?php $__env->startSection('title', 'Купон ' . $coupon->title); ?>

<?php $__env->startSection('content'); ?>

    <div class="page">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <?php echo $__env->make('auth.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-9">
                    <h1>Купон <?php echo e($coupon->title); ?></h1>
                    <table class="table">
                        <tr>
                            <td>ID</td>
                            <td><?php echo e($coupon->id); ?></td>
                        </tr>
                        <tr>
                            <td>Код</td>
                            <td><?php echo e($coupon->code); ?></td>
                        </tr>
                        <tr>
                            <td>Абсолютное значение</td>
                            <td><?php if($coupon->isAbsolute()): ?>
                                    Да
                                <?php else: ?>
                                    Нет
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td>Скидка</td>
                            <td><?php echo e($coupon->value); ?>

                                <?php if($coupon->isAbsolute()): ?>
                                    <?php echo e($coupon->currency->symbol); ?>

                                <?php else: ?>
                                    %
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php if(isset($coupon->currency)): ?>
                            <tr>
                                <td>Валюта</td>
                                <td><?php echo e($coupon->currency->code ?? null); ?></td>
                            </tr>
                        <?php endif; ?>
                        <tr>
                            <td>Использовать один раз</td>
                            <td><?php if($coupon->isOnlyOnce()): ?>
                                    Да
                                <?php else: ?>
                                    Нет
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td>Использован</td>
                            <td><?php echo e($coupon->orders->count()); ?></td>
                        </tr>
                        <?php if(isset($coupon->expired_at)): ?>
                            <tr>
                                <td>Действителен до:</td>
                                <td><?php echo e($coupon->changeDate()); ?></td>
                            </tr>
                        <?php endif; ?>
                        <tr>
                            <td>Описание</td>
                            <td><?php echo e($coupon->description); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/phplaravel/resources/views/auth/coupons/show.blade.php ENDPATH**/ ?>