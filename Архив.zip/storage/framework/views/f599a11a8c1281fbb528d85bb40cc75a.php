<?php if(isset($product)): ?>
    <?php $__env->startSection('title', 'Редактировать  ' . $product->title); ?>
<?php else: ?>
    <?php $__env->startSection('title', 'Создать продукцию'); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <?php echo $__env->make('auth.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-9">
                    <?php if(isset($product)): ?>
                        <h1>Редактировать продукцию <?php echo e($product->title); ?></h1>
                    <?php else: ?>
                        <h1>Создать продукцию</h1>
                    <?php endif; ?>
                    <form method="post" enctype="multipart/form-data"
                          <?php if(isset($product)): ?>
                              action="<?php echo e(route('products.update', $product)); ?>"
                          <?php else: ?>
                              action="<?php echo e(route('products.store')); ?>"
                            <?php endif; ?>
                    >
                        <?php if(isset($product)): ?>
                            <?php echo method_field('PUT'); ?>
                        <?php endif; ?>
                        <?php echo $__env->make('auth.layouts.error', ['fieldname' => 'code'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="form-group">
                            <label for="">Код</label>
                            <input type="text" name="code" value="<?php echo e(old('code', isset($product) ? $product->code :
                             null)); ?>">
                        </div>
                        <?php echo $__env->make('auth.layouts.error', ['fieldname' => 'title'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="form-group">
                            <label for="">Заголовок</label>
                            <input type="text" name="title" value="<?php echo e(old('title', isset($product) ? $product->title :
                             null)); ?>">
                        </div>
                        <?php echo $__env->make('auth.layouts.error', ['fieldname' => 'title_en'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="form-group">
                            <label for="">Заголовок EN</label>
                            <input type="text" name="title_en" value="<?php echo e(old('title_en', isset($product) ?
                                $product->title_en :
                             null)); ?>">
                        </div>
                        <?php echo $__env->make('auth.layouts.error', ['fieldname' => 'category_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="form-group">
                            <label for="">Категория</label>
                            <select name="category_id">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"
                                            <?php if(isset($product)): ?>
                                                <?php if($product->category_id == $category->id): ?>
                                                    selected
                                            <?php endif; ?>
                                            <?php endif; ?>
                                    ><?php echo e($category->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <?php echo $__env->make('auth.layouts.error', ['fieldname' => 'description'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="form-group">
                            <label for="">Описание</label>
                            <textarea name="description" rows="3"><?php echo e(old('description', isset($product) ?
                            $product->description : null)); ?></textarea>
                        </div>
                        <?php echo $__env->make('auth.layouts.error', ['fieldname' => 'description_en'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="form-group">
                            <label for="">Описание EN</label>
                            <textarea name="description_en" rows="3"><?php echo e(old('description_en', isset($product) ?
                            $product->description_en : null)); ?></textarea>
                        </div>

                        <?php echo $__env->make('auth.layouts.error', ['fieldname' => 'property_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="form-group">
                            <label for="">Свойство продукции</label>
                            <select name="property_id[]" multiple>
                                <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($property->id); ?>"
                                            <?php if(isset($product)): ?>
                                                <?php if($product->properties->contains($property->id)): ?>
                                                    selected
                                            <?php endif; ?>
                                            <?php endif; ?>
                                    ><?php echo e($property->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>








                        <div class="form-group">
                            <label for="">Доп изображения</label>
                            <input type="file" name="image[]" multiple="true"/>
                        </div>
                        <?php $__currentLoopData = [
                          'hit' => 'Хит',
                          'new' => 'Новинка',
                          'recommend' => 'Рекомендуемые',
                        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-group form-label">
                                <input type="checkbox" name="<?php echo e($field); ?>" id="<?php echo e($field); ?>"
                                       <?php if(isset($product) && $product->$field === 1): ?>
                                           checked="checked"
                                <?php endif; ?>>
                                <label for="<?php echo e($field); ?>"><?php echo e($title); ?></label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php echo csrf_field(); ?>
                        <button class="more">Отправить</button>
                        <a href="<?php echo e(url()->previous()); ?>" class="btn delete cancel">Отмена</a>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/phplaravel/resources/views/auth/products/form.blade.php ENDPATH**/ ?>