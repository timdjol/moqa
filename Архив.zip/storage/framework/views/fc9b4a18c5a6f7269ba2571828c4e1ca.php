<div class="sidebar">
    <ul>
        <?php if (\Illuminate\Support\Facades\Blade::check('admin')): ?>
            <li <?php echo Route::currentRouteNamed('dashboard') ? 'class="active"' : ''  ?>><a href="<?php echo e(route('dashboard')); ?>">Консоль</a></li>
            <li <?php echo Route::currentRouteNamed('categories.index') ? 'class="active"' : ''  ?>><a href="<?php echo e(route('categories.index')); ?>">Категории</a></li>
            <li <?php echo Route::currentRouteNamed('products.index') ? 'class="active"' : ''  ?>><a href="<?php echo e(route('products.index')); ?>">Продукции</a></li>
            <li <?php echo Route::currentRouteNamed('properties.index') ? 'class="active"' : ''  ?>><a href="<?php echo e(route('properties.index')); ?>">Свойства</a></li>
            <li <?php echo Route::currentRouteNamed('coupons.index') ? 'class="active"' : ''  ?>><a href="<?php echo e(route('coupons.index')); ?>">Купоны</a></li>
            <li <?php echo Route::currentRouteNamed('orders.index') ? 'class="active"' : ''  ?>><a href="<?php echo e(route('orders.index')); ?>">Заказы</a></li>
            <li <?php echo Route::currentRouteNamed('pages.index') ? 'class="active"' : ''  ?>><a href="<?php echo e(route('pages.index')); ?>">Страницы</a></li>
            <li <?php echo Route::currentRouteNamed('contacts.index') ? 'class="active"' : ''  ?>><a href="<?php echo e(route('contacts.index')); ?>">Контакты</a></li>
            <li><a href="<?php echo e(route('profile.edit')); ?>">Профиль</a></li>
        <?php else: ?>
            <li <?php echo Route::currentRouteNamed('person.orders.index') ? 'class="active"' : ''  ?>><a href="<?php echo e(route('person.orders.index')); ?>">Заказы</a></li>
            <li><a href="<?php echo e(route('profile.edit')); ?>">Профиль</a></li>
        <?php endif; ?>
    </ul>
</div>
<?php /**PATH /Users/timdjol/Sites/localhost/phplaravel/resources/views/auth/layouts/sidebar.blade.php ENDPATH**/ ?>