<?php if(isset($coupon)): ?>
    <?php $__env->startSection('title', 'Редактировать купон'); ?>
<?php else: ?>
    <?php $__env->startSection('title', 'Добавить купон'); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <?php echo $__env->make('auth.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-9">
                    <?php if(isset($coupon)): ?>
                        <h1>Редактировать купон</h1>
                    <?php else: ?>
                        <h1>Добавить купон</h1>
                    <?php endif; ?>
                    <form method="post"
                          <?php if(isset($coupon)): ?>
                              action="<?php echo e(route('coupons.update', $coupon)); ?>"
                          <?php else: ?>
                              action="<?php echo e(route('coupons.store')); ?>"
                            <?php endif; ?>
                    >
                        <?php if(isset($coupon)): ?>
                            <?php echo method_field('PUT'); ?>
                        <?php endif; ?>
                        <?php echo $__env->make('auth.layouts.error', ['fieldname' => 'code'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="form-group">
                            <label for="">Код</label>
                            <input type="text" name="code" value="<?php echo e(old('code', isset($coupon) ? $coupon->code :
                             null)); ?>">
                        </div>
                        <?php echo $__env->make('auth.layouts.error', ['fieldname' => 'value'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="form-group">
                            <label for="">Номинал</label>
                            <input type="text" name="value" value="<?php echo e(old('value', isset($coupon) ? $coupon->value :
                             null)); ?>">
                        </div>
                        <?php echo $__env->make('auth.layouts.error', ['fieldname' => 'currency_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="form-group">
                            <label for="">Валюта</label>
                            <select name="currency_id">
                                <option value="">Без валюты</option>
                                <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($currency->id); ?>"
                                            <?php if(isset($coupon)): ?>
                                                <?php if($coupon->currency_id == $currency->id): ?>
                                                    selected
                                            <?php endif; ?>
                                            <?php endif; ?>
                                    ><?php echo e($currency->code); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <?php $__currentLoopData = [
                            'type' => 'Абсолютное значение',
                            'only_once' => 'Купон может быть использован только один раз',
                        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-group">
                                <input type="checkbox" name="<?php echo e($field); ?>"
                                       <?php if(isset($coupon) && $coupon->$field === 1): ?>
                                           checked="checked"
                                <?php endif; ?>
                                <label for=""><?php echo e($title); ?></label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('auth.layouts.error', ['fieldname' => 'expired_at'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="form-group">
                            <label for="">Использовать до:</label>
                            <input type="date" name="expired_at" value="<?php echo e(old('description', isset($coupon) ?
                            $coupon->changeDateForm() : null)); ?>">
                        </div>
                        <?php echo $__env->make('auth.layouts.error', ['fieldname' => 'description'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="form-group">
                            <label for="">Описание</label>
                            <textarea name="description" rows="3"><?php echo e(old('description', isset($coupon) ?
                            $coupon->description : null)); ?></textarea>
                        </div>
                        <?php echo csrf_field(); ?>
                        <button class="more">Отправить</button>
                            <a href="<?php echo e(url()->previous()); ?>" class="btn delete cancel">Отмена</a>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/phplaravel/resources/views/auth/coupons/form.blade.php ENDPATH**/ ?>