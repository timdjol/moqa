<div class="products-item">
    <div class="img-wrap">
        <div class="labels">
            <?php if($sku->product->isNew()): ?>
                <div class="badge badge-success"><?php echo app('translator')->get('main.properties.new'); ?></div>
            <?php endif; ?>
            <?php if($sku->product->isRecommend()): ?>
                <div class="badge badge-warning"><?php echo app('translator')->get('main.properties.recommend'); ?></div>
            <?php endif; ?>
            <?php if($sku->product->isHit()): ?>
                <div class="badge badge-danger"><?php echo app('translator')->get('main.properties.hit'); ?></div>
            <?php endif; ?>
        </div>
        <a href="<?php echo e(route('sku', [$sku->product->category->code, $sku->product->code, $sku])); ?>">
            <div class="img" style="background-image: url(<?php echo e(Storage::url($sku->product->image)); ?>)"></div>
        </a>
    </div>
    <h4><?php echo e($sku->product->__('title')); ?></h4>
    <?php if(isset($sku->product->properties)): ?>
        <?php $__currentLoopData = $sku->propertyOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $propertyOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p style="margin-bottom: 0"><?php echo e($propertyOption->property->__('title')); ?>: <?php echo e($propertyOption->__
                ('title')); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <div class="price"><?php echo e($sku->price); ?> <?php echo e($currencySymbol); ?></div>
    <?php if($sku->isAvailable()): ?>
        <form action="<?php echo e(route('basket-add', $sku)); ?>" method="POST">
            <button class="more" type="submit"><?php echo app('translator')->get('main.addtocart'); ?></button>
            <?php echo csrf_field(); ?>
        </form>
    <?php else: ?>
        <p><?php echo app('translator')->get('main.no_available'); ?></p>
    <?php endif; ?>
    <div class="wishlist">
        <form action="<?php echo e(route('wishlist-add', $sku)); ?>" method="POST">
            <button>
                <svg width="800px" height="800px" viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg"
                     stroke-width="1.5"
                     stroke="#fff" fill="none">
                    <path d="M9.06,25C7.68,17.3,12.78,10.63,20.73,10c7-.55,10.47,7.93,11.17,9.55a.13.13,0,0,0,.25,0c3.25-8.91,9.17-9.29,11.25-9.5C49,9.45,56.51,13.78,55,23.87c-2.16,14-23.12,29.81-23.12,29.81S11.79,40.05,9.06,25Z"/>
                </svg>
            </button>
            <?php echo csrf_field(); ?>
        </form>
    </div>
</div>

<?php /**PATH /Users/timdjol/Sites/localhost/phplaravel/resources/views/layouts/cart.blade.php ENDPATH**/ ?>