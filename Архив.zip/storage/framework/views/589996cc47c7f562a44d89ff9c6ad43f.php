<?php $__env->startSection('title', 'Главная страница'); ?>

<?php $__env->startSection('content'); ?>

    <div class="slider">
        <div class="owl-carousel owl-slider">
            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="slider-item" style="background-image: url(<?php echo e(Storage::url($slider->image)); ?>)">
                    <div class="container">
                        <div class="text-wrap">
                            <h2><?php echo e($slider->__('title')); ?></h2>
                            <?php if($slider->link): ?>
                                <div class="btn-wrap">
                                    <a href="<?php echo e($slider->link); ?>" class="more"><?php echo app('translator')->get('main.readmore'); ?></a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="products novelties">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2>Новинки</h2>
                    <div class="owl-carousel owl-products">
                        <?php $__currentLoopData = $skus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('layouts.cart', compact('sku'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="products coming">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2>Скоро в продаже</h2>
                    <div class="owl-carousel owl-products">
                        <?php $__currentLoopData = $soons->map->skus->flatten(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('layouts.cart', compact('sku'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="products capsule">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2>Капсула</h2>
                    <div class="owl-carousel owl-products">
                        <?php $__currentLoopData = $capsules->map->skus->flatten(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('layouts.cart', compact('sku'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="products clothes">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2>Одежда</h2>
                    <div class="owl-carousel owl-products">
                        <?php $__currentLoopData = $clothes->map->skus->flatten(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('layouts.cart', compact('sku'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="products sport">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2>Одежда для спорта</h2>
                    <div class="owl-carousel owl-products">
                        <?php $__currentLoopData = $sports->map->skus->flatten(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('layouts.cart', compact('sku'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="products home">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2>Одежда для дома</h2>
                    <div class="owl-carousel owl-products">
                        <?php $__currentLoopData = $homes->map->skus->flatten(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('layouts.cart', compact('sku'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="products beach">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2>Пляж</h2>
                    <div class="owl-carousel owl-products">
                        <?php $__currentLoopData = $beaches->map->skus->flatten(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('layouts.cart', compact('sku'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="products underwear">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2>Нижнее белье</h2>
                    <div class="owl-carousel owl-products">
                        <?php $__currentLoopData = $underwears->map->skus->flatten(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('layouts.cart', compact('sku'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="products socks">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2>Носки и колготки</h2>
                    <div class="owl-carousel owl-products">
                        <?php $__currentLoopData = $socks->map->skus->flatten(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('layouts.cart', compact('sku'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="products access">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2>Аксессуары</h2>
                    <div class="owl-carousel owl-products">
                        <?php $__currentLoopData = $access->map->skus->flatten(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('layouts.cart', compact('sku'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="products cosmetic">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2>Косметика</h2>
                    <div class="owl-carousel owl-products">
                        <?php $__currentLoopData = $cosmetics->map->skus->flatten(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('layouts.cart', compact('sku'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="products sale">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2>SALE</h2>
                    <div class="owl-carousel owl-products">
                        <?php $__currentLoopData = $sales->map->skus->flatten(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('layouts.cart', compact('sku'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/phplaravel/resources/views/index.blade.php ENDPATH**/ ?>