<?php

namespace App\Services;

class CurrencyRates
{

}