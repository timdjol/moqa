<?php

return [
    'added_cart' => 'Products added ',
    'item' => 'Item ',
    'unavailable' => ' more unavailable for order',
    'delete_product' => 'Item removed ',
    'unavailable_full' => 'Products are not available for order in full',
    'processed' => 'Your order has been processed!',
    'basket' => 'Cart',
    'name' => 'Name',
    'count' => 'Quantity',
    'price' => 'Price',
    'cost' => 'Cost',
    'total_cost' => 'Total cost',
    'checkout_btn' => 'Checkout',
    'checkout' => 'Checkout',
    'total_order' => 'Total order value',
    'your_name' => 'Your name',
    'phone' => 'Phone number',
    'confirm' => 'Confirm order',
    'empty_cart' => 'Your basket is empty!'
];