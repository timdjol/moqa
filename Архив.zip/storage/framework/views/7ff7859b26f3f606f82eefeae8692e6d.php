<?php if(isset($sku)): ?>
    <?php $__env->startSection('title', 'Редактировать Sku' . $sku->title); ?>
<?php else: ?>
    <?php $__env->startSection('title', 'Добавить Sku'); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>

    <div class="page admin">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <?php echo $__env->make('auth.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-9">
                    <?php if(isset($sku)): ?>
                        <h1>Редактировать Sku <?php echo e($sku->title); ?></h1>
                    <?php else: ?>
                        <h1>Создать Sku</h1>
                    <?php endif; ?>
                    <form method="post"
                          <?php if(isset($sku)): ?>
                              action="<?php echo e(route('skus.update', [$product, $sku])); ?>"
                          <?php else: ?>
                              action="<?php echo e(route('skus.store', $product)); ?>"
                            <?php endif; ?>
                    >
                        <?php if(isset($sku)): ?>
                            <?php echo method_field('PUT'); ?>
                        <?php endif; ?>
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <label for="">Цена</label>
                            <?php echo $__env->make('auth.layouts.error', ['fieldname' => 'price'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <input type="text" name="price" value="<?php if(isset($sku)): ?><?php echo e($sku->price); ?><?php endif; ?>">
                        </div>

                        <div class="form-group">
                            <label for="">Кол-во</label>
                            <?php echo $__env->make('auth.layouts.error', ['fieldname' => 'count'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <input type="text" name="count" value="<?php if(isset($sku)): ?><?php echo e($sku->count); ?><?php endif; ?>">
                        </div>

                        <div class="form-group">
                            <?php $__currentLoopData = $product->properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="input-group row">
                                    <label for="property_id[<?php echo e($property->id); ?>]" class="col-sm-2 col-form-label"><?php echo e($property->title); ?>: </label>
                                    <div class="col-sm-4">
                                        <select name="property_id[<?php echo e($property->id); ?>]" class="form-control">
                                            <?php $__currentLoopData = $property->propertyOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $propertyOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($propertyOption->id); ?>"
                                                        <?php if(isset($sku)): ?>
                                                            <?php if($sku->propertyOptions->contains($propertyOption->id)): ?>
                                                                selected
                                                        <?php endif; ?>
                                                        <?php endif; ?>
                                                ><?php echo e($propertyOption->title); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <button class="more">Отправить</button>
                        <a href="<?php echo e(url()->previous()); ?>" class="btn delete cancel">Отмена</a>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/phplaravel/resources/views/auth/skus/form.blade.php ENDPATH**/ ?>