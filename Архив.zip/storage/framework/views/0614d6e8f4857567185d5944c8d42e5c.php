<?php $__env->startSection('title', 'Корзина'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page cart basket">
        <div class="container">
            <div class="col-md-12">
                <h1><?php echo app('translator')->get('basket.basket'); ?></h1>
                <table>
                    <tr>
                        <td><?php echo app('translator')->get('basket.name'); ?></td>
                        <td><?php echo app('translator')->get('basket.count'); ?></td>
                        <td><?php echo app('translator')->get('basket.price'); ?></td>
                        <td><?php echo app('translator')->get('basket.cost'); ?></td>
                    </tr>
                    <?php $__currentLoopData = $order->skus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <a href="<?php echo e(route('sku', [$sku->product->category->code, $sku->product->code,
                                $sku->id])); ?>">
                                    <img src="<?php echo e(Storage::url($sku->product->image)); ?>" alt="<?php echo e($sku->product->__
                                    ('title')); ?>">
                                    <?php echo e($sku->product->__('title')); ?>

                                </a>
                            </td>
                            <td>
                                <form action="<?php echo e(route('basket-remove', $sku)); ?>" method="post">
                                    <button type="submit" class="btn btn-danger">-</button>
                                    <?php echo csrf_field(); ?>
                                </form>
                                <span class="badge"><?php echo e($sku->countInOrder); ?></span>
                                <form action="<?php echo e(route('basket-add', $sku)); ?>" method="post">
                                    <button type="submit" class="btn btn-success">+</button>
                                    <?php echo csrf_field(); ?>
                                </form>
                            </td>
                            <td><?php echo e($sku->price); ?> <?php echo e($currencySymbol); ?></td>
                            <td><?php echo e($sku->price * $sku->countInOrder); ?> <?php echo e($currencySymbol); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td colspan="3"><?php echo app('translator')->get('basket.total_cost'); ?></td>
                        <?php if($order->hasCoupon()): ?>
                            <td><strike><?php echo e($order->getFullSum(false)); ?> <?php echo e($currencySymbol); ?></strike> <b><?php echo e($order->getFullSum()); ?> <?php echo e($currencySymbol); ?></b></td>
                        <?php else: ?>
                            <td><?php echo e($order->getFullSum()); ?> <?php echo e($currencySymbol); ?></td>
                        <?php endif; ?>
                    </tr>
                </table>
                <?php if(!$order->hasCoupon()): ?>
                <div class="row">
                    <div class="col-md-4">
                        <div class="coupon">
                            <form action="<?php echo e(route('set-coupon')); ?>" method="post">
                                <?php $__errorArgs = ['coupon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div class="form-group">
                                    <label for="">Ваш промокод</label>
                                    <input type="text" name="coupon">
                                    <button class="more">Применить</button>
                                </div>
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </div>
                </div>
                <?php else: ?>
                    <p>Вы используете купон <?php echo e($order->coupon->code); ?></p>
                <?php endif; ?>
                <div class="row">
                    <div class="col-md-4">
                        <div class="btn-wrap">
                            <a href="<?php echo e(route('order')); ?>" class="more"><?php echo app('translator')->get('basket.checkout_btn'); ?></a>
                        </div>
                    </div>
                    <div class="col-md-8 btns">
                        <div class="btn-wrap">
                            <ul>
                                <li><a href="<?php echo e(route('catalog')); ?>" class="more">Продолжить покупки</a></li>
                                <li><a href="<?php echo e(route('basket-reset')); ?>" class="more delete">Очистить корзину</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/timdjol/Sites/localhost/phplaravel/resources/views/basket.blade.php ENDPATH**/ ?>